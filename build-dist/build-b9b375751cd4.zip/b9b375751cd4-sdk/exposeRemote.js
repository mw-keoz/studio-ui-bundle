
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/b9b375751cd4-sdk/static/js/remoteEntry.js'
    