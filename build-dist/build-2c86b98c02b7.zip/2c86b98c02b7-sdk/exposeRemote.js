
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/2c86b98c02b7-sdk/static/js/remoteEntry.js'
    